package com.ex.dao;

import com.ex.dto.BoardDto;
import com.ex.dto.UserDto;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Dao {

    DataSource ds;
    public static final int USER_EXISTENT = 1;
    public static final int USER_NONEXISTENT = 2;
    public static final int USER_JOIN_SUCCESS = 3;
    public static final int USER_LOGIN_SUCCESS = 4;
    public static final int USER_LOGIN_FAIL = 5;
    public static final int BOARD__SUCCESS = 6;

    public Dao() {
        String jndiName = "jdbc/mysql";
        try {
            Context initContext = (Context) new InitialContext().lookup("java:/comp/env");
            ds = (DataSource) initContext.lookup(jndiName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int insertUser(UserDto user) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = "INSERT INTO USER (ID,PW,NAME,EMAIL,ADDRESS) VALUES (?,?,?,?,?)";
        try {
            conn = ds.getConnection();

            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, user.getId());
            pstmt.setString(2, user.getPw());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5, user.getAddress());
            pstmt.executeUpdate();
            rt = USER_JOIN_SUCCESS;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return rt;
    }

    public int updateUser(String id, String pw, String email, String address) {
        int rt = 0;

        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = "UPDATE USER SET PW=?, EMAIL=?, ADDRESS=? WHERE ID=?";
        try {
            conn = ds.getConnection();

            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, pw);
            pstmt.setString(2, email);
            pstmt.setString(3, address);
            pstmt.setString(4, id);
            rt = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return rt;
    }

    public int insertBoard(String user_id, String title, String content) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String query1 = "SELECT MAX(ID) FROM BOARD";
        String query2 = "INSERT INTO BOARD (USER_ID,TITLE,CONTENT,VIEWS,GROUP_ID,STEP,INDENT) VALUES (?,?,?,0,?,0,0)";
        try {
            conn = ds.getConnection();

            if (conn == null) return rt;
            pstmt = conn.prepareStatement(query1);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                pstmt = conn.prepareStatement(query2);
                pstmt.setString(1, user_id);
                pstmt.setString(2, title);
                pstmt.setString(3, content);
                pstmt.setInt(4, rs.getInt(1)+1);
                rt = pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return rt;
    }

    public int reply(String user_id, String title, String content, int group_id, int step, int indent) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        String query1 = "UPDATE BOARD SET STEP = STEP +1 WHERE GROUP_ID = ? AND STEP > ?";
        String query2 = "INSERT INTO BOARD (USER_ID,TITLE,CONTENT,VIEWS,GROUP_ID,STEP,INDENT) VALUES (?,?,?,0,?,?,?)";
        try {
            conn = ds.getConnection();
            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query1);
            pstmt.setInt(1,group_id);
            pstmt.setInt(2,step);
            System.out.println(pstmt.executeUpdate());

            pstmt = conn.prepareStatement(query2);
            pstmt.setString(1, user_id);
            pstmt.setString(2, title);
            pstmt.setString(3, content);
            pstmt.setInt(4, group_id);
            pstmt.setInt(5, step + 1);
            pstmt.setInt(6, indent + 1);
            rt = pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return rt;
    }

    public int updateBoard(String bId, String title, String content) {
        int rt = 0;

        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = "UPDATE BOARD SET TITLE=?, CONTENT=? WHERE ID=?";
        try {
            conn = ds.getConnection();
            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, title);
            pstmt.setString(2, content);
            pstmt.setInt(3, Integer.parseInt(bId));
            rt = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return rt;
    }

    public int updateViews(String id) {
        int rt = 0;

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String query1 = "SELECT VIEWS FROM BOARD WHERE ID=?";
        String query2 = "UPDATE BOARD SET VIEWS=? WHERE ID=?";
        try {
            conn = ds.getConnection();
            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query1);
            pstmt.setInt(1, Integer.parseInt(id));
            rs = pstmt.executeQuery();
            if (rs.next()) {
                pstmt = conn.prepareStatement(query2);
                pstmt.setInt(1, rs.getInt("views") + 1);
                pstmt.setInt(2, Integer.parseInt(id));
                rt = pstmt.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return rt;
    }

    public int confirmId(String id) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String query = "SELECT ID FROM USER WHERE ID = ?";

        try {
            conn = ds.getConnection();
            if (conn == null) return rt;
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            if (rs.next())
                rt = USER_EXISTENT;
            else
                rt = USER_NONEXISTENT;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return rt;
    }

    public int confirmLogin(String id, String pw) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String query = "SELECT PW FROM USER WHERE ID = ?";

        try {
            conn = ds.getConnection();

            if (conn == null) return rt;
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                if (pw.equals(rs.getString("pw")))
                    rt = USER_LOGIN_SUCCESS;
                else
                    rt = USER_LOGIN_FAIL;
            } else
                rt = USER_NONEXISTENT;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return rt;
    }

    public UserDto getUser(String id) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        UserDto user = null;

        String query = "SELECT * FROM USER WHERE ID = ?";

        try {
            conn = ds.getConnection();

            if (conn == null) return user;
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                user = new UserDto(rs.getString("id"),
                        rs.getString("pw"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getTimestamp("date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return user;
    }

    public BoardDto getBoard(String id) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BoardDto board = null;

        String query = "SELECT * FROM BOARD WHERE ID = ?";

        try {
            conn = ds.getConnection();

            if (conn == null) return board;
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                board = new BoardDto(rs.getInt("id"),
                        rs.getString("user_id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getTimestamp("date"),
                        rs.getInt("views"),
                        rs.getInt("group_id"),
                        rs.getInt("step"),
                        rs.getInt("indent"));
                System.out.println(board.toString());
            }


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return board;
    }

    public ArrayList<BoardDto> getBoardList() {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<BoardDto> list = new ArrayList<>();

        String query = "SELECT * FROM BOARD ORDER BY GROUP_ID DESC, STEP ASC";

        try {
            conn = ds.getConnection();

            if (conn == null) return list;
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new BoardDto(rs.getInt("id"),
                        rs.getString("user_id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getTimestamp("date"),
                        rs.getInt("views"),
                        rs.getInt("group_id"),
                        rs.getInt("step"),
                        rs.getInt("indent")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public ArrayList<BoardDto> getMyBoardList(String id) {
        int rt = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<BoardDto> list = new ArrayList<>();

        String query = "SELECT * FROM BOARD WHERE USER_ID=?";

        try {
            conn = ds.getConnection();

            if (conn == null) return list;

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new BoardDto(rs.getInt("id"),
                        rs.getString("user_id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getTimestamp("date"),
                        rs.getInt("views"),
                        rs.getInt("group_id"),
                        rs.getInt("step"),
                        rs.getInt("indent")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public int removeBoard(String id) {
        int rt = 0;

        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = "DELETE FROM BOARD WHERE ID=?";
        try {
            conn = ds.getConnection();

            if (conn == null) return rt;

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);

            rt = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return rt;
    }


}
