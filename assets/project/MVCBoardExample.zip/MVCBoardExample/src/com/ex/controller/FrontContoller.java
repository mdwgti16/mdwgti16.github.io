package com.ex.controller;

import com.ex.command.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("*.do")
public class FrontContoller extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        actionDo(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        actionDo(request, response);
    }

    private void actionDo(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        if (request.getSession().getAttribute("isLogin") == null)
            request.getSession().setAttribute("isLogin", false);

        String viewPage = null;
        Command cmd = null;
        String com = request.getRequestURI();
//        String conPath = request.getContextPath();
//        String com = uri.substring(conPath.length());

        System.out.println(com);
        switch (com) {
            // board
            case "/home.do":
                cmd = new ListCmd();
                cmd.execute(request,response);
                viewPage = "home.jsp";
                break;
            case "/write.do":
                viewPage = "/board/write.jsp";
                break;
            case "/write_process.do":
                cmd = new WriteCmd();
                cmd.execute(request, response);
                viewPage = "/board/result_write.jsp";
                break;
            case "/detail.do":
                cmd = new GetBoardCmd();
                cmd.execute(request,response);
                viewPage = "/board/detail.jsp";
                break;
            case "/remove.do":
                cmd = new RemoveCmd();
                cmd.execute(request,response);
                viewPage = "/board/result_remove.jsp";
                break;
            case "/board_modify.do":
                cmd = new GetBoardCmd();
                cmd.execute(request,response);
                viewPage = "/board/board_modify.jsp";
                break;
            case "/board_modify_process.do":
                cmd = new BoardModifyCmd();
                cmd.execute(request,response);
                viewPage = "/board/result_modify.jsp";
                break;
            case "/reply.do":
                cmd = new ReplyViewCmd();
                cmd.execute(request,response);
                viewPage = "/board/reply.jsp";
                break;
            case "/reply_process.do":
                cmd = new ReplyCmd();
                cmd.execute(request,response);
                viewPage = "/board/result_reply.jsp";
                break;

            // user
            case "/login.do":
                viewPage = "/user/login.jsp";
                break;
            case "/login_process.do":
                cmd = new LoginCmd();
                cmd.execute(request, response);
                viewPage = "/user/result_login.jsp";
                break;
            case "/join.do":
                viewPage = "/user/join.jsp";
                break;
            case "/join_process.do":
                cmd = new JoinCmd();
                cmd.execute(request, response);
                viewPage = "/user/result_join.jsp";
                break;

            case "/user_modify.do":
                viewPage = "/user/user_modify.jsp";
                break;
            case "/user_modify_process.do":
                cmd = new UserModifyCmd();
                cmd.execute(request, response);
                viewPage = "/user/result_modify.jsp";
                break;
            case "/logout.do":
                viewPage = "/user/logout.jsp";
                break;

            case "/my_board.do":
                cmd = new MyBoardCmd();
                cmd.execute(request,response);
                viewPage = "my_board.jsp";
                break;

            case "/session_gone.do":
                viewPage = "/user/session_gone.jsp";
                break;
            default:
                viewPage = "/home.do";
        }

        RequestDispatcher rd = request.getRequestDispatcher(viewPage);
        rd.forward(request, response);

    }

}
