package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BoardModifyCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String bId = request.getParameter("board_id");
        request.setAttribute("rt",dao.updateBoard(bId,title,content));
    }
}
