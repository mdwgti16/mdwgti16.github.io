package com.ex.command;

import com.ex.dao.Dao;
import com.ex.dto.BoardDto;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReplyViewCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        BoardDto board = dao.getBoard(request.getParameter("board_id"));
        System.out.println(board.toString());
        request.setAttribute("board",board);
    }
}
