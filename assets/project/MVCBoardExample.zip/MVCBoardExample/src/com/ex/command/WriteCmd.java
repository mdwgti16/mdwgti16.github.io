package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        String user_id = (String) request.getSession().getAttribute("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        request.setAttribute("rt", dao.insertBoard(user_id,title,content));
    }
}
