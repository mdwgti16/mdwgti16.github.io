package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserModifyCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        String id = (String) request.getSession().getAttribute("id");
        String pw = request.getParameter("pw");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        if(pw.isEmpty())
            return;
        request.setAttribute("rt", dao.updateUser(id, pw, email, address));
    }
}
