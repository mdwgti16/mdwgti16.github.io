package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetBoardCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        String board_id = request.getParameter("board_id");
        dao.updateViews(board_id);
        request.setAttribute("board",dao.getBoard(board_id));
    }
}
