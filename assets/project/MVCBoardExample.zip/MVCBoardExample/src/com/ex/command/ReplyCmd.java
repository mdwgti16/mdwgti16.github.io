package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReplyCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();

        String user_id = request.getParameter("user_id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        int group_id = Integer.parseInt(request.getParameter("group_id"));
        int step = Integer.parseInt(request.getParameter("step"));
        int indent = Integer.parseInt(request.getParameter("indent"));

        request.setAttribute("rt", dao.reply(user_id, title, content, group_id, step, indent));
    }
}
