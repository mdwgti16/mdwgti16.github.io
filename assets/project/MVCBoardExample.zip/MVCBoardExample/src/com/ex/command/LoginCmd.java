package com.ex.command;

import com.ex.dao.Dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();

        String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        int rt = 0;
        rt = dao.confirmLogin(id, pw);
        if (rt == Dao.USER_LOGIN_SUCCESS) {
            request.setAttribute("user",dao.getUser(id));
        }

        request.setAttribute("rt", rt);
    }
}