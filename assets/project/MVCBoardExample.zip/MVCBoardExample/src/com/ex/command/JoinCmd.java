package com.ex.command;

import com.ex.dao.Dao;
import com.ex.dto.UserDto;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JoinCmd implements Command {
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        Dao dao = new Dao();
        UserDto user = new UserDto(request.getParameter("id"),
                request.getParameter("pw"),
                request.getParameter("name"),
                request.getParameter("email"),
                request.getParameter("address"), null);

        request.setAttribute("rt", dao.insertUser(user));
    }
}
