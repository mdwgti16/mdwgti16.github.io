package com.ex.dto;

import java.sql.Timestamp;

public class BoardDto {
    private int id;
    private String user_id;
    private String title;
    private String content;
    private Timestamp date;
    private int views;
    private int group_id;
    private int step;
    private int indent;

    public BoardDto() {
    }

    public BoardDto(int id, String user_id, String title, String content, Timestamp date, int views, int group_id, int step, int indent) {
        this.id = id;
        this.user_id = user_id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.views = views;
        this.group_id = group_id;
        this.step = step;
        this.indent = indent;
    }

    public int getId() {
        return id;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Timestamp getDate() {
        return date;
    }

    public int getViews() {
        return views;
    }

    public int getGroup_id() {
        return group_id;
    }

    public int getStep() {
        return step;
    }

    public int getIndent() {
        return indent;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public void setViews(int views) {
        this.views = views;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public void setStep(int step) {
        this.step = step;
    }

    public void setIndent(int indent) {
        this.indent = indent;
    }

    @Override
    public String toString() {
        return "BoardDto{" +
                "id=" + id +
                ", user_id='" + user_id + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", views=" + views +
                ", group_id=" + group_id +
                ", step=" + step +
                ", indent=" + indent +
                '}';
    }
}
