function confirmForm(name) {
    var c;

    if (typeof (name) === "object")
        c = name;
    else
        c = document.getElementsByName(name)[0];


    if (c.hasOwnProperty("id") && c.id.value === "") {
        alert("아이디를 입력하세요.");
        c.id.focus();
        return;
    }

    if (c.hasOwnProperty("pw") && c.pw.value === "") {
        alert("비밀번호를 입력하세요.");
        c.pw.focus();
        return;
    }

    if (c.hasOwnProperty("name") && c.name.value === "") {
        alert("이름을 입력하세요.");
        c.name.focus();
        return;
    }

    if (c.hasOwnProperty("email") && c.email.value === "") {
        alert("이메일 입력하세요.");
        c.email.focus();
        return;
    }

    if (c.hasOwnProperty("address") && c.address.value === "") {
        alert("주소를 입력하세요.");
        c.address.focus();
        return;
    }

    if (c.hasOwnProperty("title") && c.title.value === "") {
        alert("제목을 입력하세요.");
        c.title.focus();
        return;
    }

    if (c.hasOwnProperty("content") && c.content.value === "") {
        alert("내용을 입력하세요.");
        c.content.focus();
        return;
    }


    c.submit();
}

