package ex.spring.controller;

import ex.spring.api.Kakao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;

@Controller
public class UserController {
    @Autowired
    private Kakao kakao;

    @RequestMapping(value = "/")
    public String kakao(){
        System.out.println("kakao");
        return "kakao";
    }

    @RequestMapping(value="/oauth")
    public String oauth(@RequestParam("code") String code, Model model) {
        String access_Token = kakao.getAccessToken(code);
        HashMap<String, Object> userInfo = kakao.getUserInfo(access_Token);
        System.out.println("login Controller : " + userInfo);
        model.addAttribute("nickname",userInfo.get("nickname"));
        model.addAttribute("email",userInfo.get("email"));

        return "index";
    }

}
